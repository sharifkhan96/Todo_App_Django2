from django.contrib import admin
from .models import MyTask

# Register your models here.

admin.site.register(MyTask)
